// AUTHOR:Giuliano Lupi
//DATE:12/04/2022
//TITLE:SPACE_INVADERS 
/*ALGORITHM:Realistica riproduzione del noto gioco Space Invaders avente un menu e diverse difficolt� da sperimentare e una colonna sonora.
Per realizzarlo � stata utilizzata la libreria alllegro.h visto che possiede funzioni molto simili a Graphics.h e permette di implementare l'intera parte audio in maniera semplicissima, 
sicch� per eseguirlo da file .dev � necessario averla installata sul proprio compilatore.
Se cos� non fosse si pu� ugualmente giocare facendo partire l'eseguibile Space_invaders_Grafica.exe e godersi l'esperienza.*/

#include <iostream>
#include <allegro.h>
#include <stdlib.h>
#include<time.h>
#include "inizio.h"
#include "spari.h"
#include "menu.h"
#define larghezza 600
#define altezza  600


/*Creo una struttura per controllare tutte le funzioni della navicella contenente
-Le coordinate
-Spari attuali e spari totali
-Il tempo che serve per distanziare uno sparo e l'altro
-L'immagine bitmap della nave
-L'immagine bitmap del proiettile
-Funzione per creare l'astronave
-Funzione per renderizzarla quando si muove
-Funzione per sparare con l'astronave
-Funzione per renderizzare le vite in ato a dx
*/
using namespace std;
//NAVICELLA
struct Navicella{
	int x=larghezza/2;
	int y=altezza-50;
	int n_spari;
	int max_spari;
	int tempo;
	int larghezza_proiettile;
	int altezza_proiettile;
	int larghezza_astronave;
	int altezza_astronave;
	int velocita_spari;
	int tipo;
	int vita;
	BITMAP*navicella;
	BITMAP*proiettile;
	BITMAP* esplosione_alieno;
	SAMPLE *sparo;
	SAMPLE *esplosione;
	
	void crea_astronave(char* nav_icella, char* pro_iettile, int larghezza_proiettile_crea, int altezza_proiettile_crea, int larghezza_astronave_crea, int altezza_astronave_crea, int x_astronave, int y_astronave, int velocita_proiettile_crea, int tipo_crea, int vita_crea, char *msuica_sparo, char *musica_esplosione);
	bool gestione_tempo(int velocita_tempo);
	void renderizza_astronave(BITMAP* sfondo, int x_iniziale, int y_iniziale);
	void muove_astronave();
	void sparo_astronave(struct Spari spari[], BITMAP* sfondo);
	void renderizza_vite(BITMAP *sfondo);
	
};
/*Creo una struttura per gli scudi, visto che hanno una gestione dei bmp pi� complicata della navicella/alieni contenente:
 -Coordinate x,y
 -Danno subito
 -Tipo per le immagini .bmp da usare
*/
struct baracca{
	int x,y;
	int danno;
	int tipo;
};
//FUNZIONI
//CREA ALIENO E NAVICELLA
void Navicella::crea_astronave(char* nav_icella, char* pro_iettile, int larghezza_proiettile_crea, int altezza_proiettile_crea, int larghezza_astronave_crea, int altezza_astronave_crea, int x_astronave, int y_astronave, int velocita_proiettile_crea, int tipo_crea, int vita_crea,  char *musica_sparo, char *musica_esplosione){
	x=x_astronave;//x navicella
	y=y_astronave;//y navicella
	n_spari=0;//spari iniziali
	max_spari=2;//spari massimi
	//grazie a allegro.h possoutilizzare load_bitmap, il parametro NULL serve per non far restituire i dati dei colori (non mi interessano)
	navicella=load_bitmap(nav_icella,NULL);//navicella � l'immagine bitmap appunto dell'astronave
	proiettile=load_bitmap(pro_iettile,NULL);//proiettile � l'immagine bitmap del proiettile
	tempo=0;
	larghezza_proiettile=larghezza_proiettile_crea;
	altezza_proiettile=altezza_proiettile_crea;
	larghezza_astronave=larghezza_astronave_crea;
	altezza_astronave=altezza_astronave_crea;
	velocita_spari=velocita_proiettile_crea;
	tipo=tipo_crea;
	vita=vita_crea;
	esplosione_alieno=load_bitmap("./Immagini/Esplosione.bmp",NULL);
	sparo=load_wav(musica_sparo);
	esplosione=load_wav(musica_esplosione);
	//cout<<"Navicella creata";
	
}
//GESTIONE TEMPO PER I PROIETTILI
bool Navicella::gestione_tempo(int velocita_tempo){
	tempo++;
	if(tempo==velocita_tempo){
		tempo=0;
		return true;
	}
	return false;
}
//RENDERIZZA LA NAVICELLA/ALIENO
void Navicella::renderizza_astronave(BITMAP* sfondo, int x_iniziale, int y_iniziale){//x_iniziale e y_iniziale servono per decidere quale sprite prendere
	masked_blit(navicella,sfondo,x_iniziale*larghezza_astronave,y_iniziale*altezza_astronave,x,y,larghezza_astronave,altezza_astronave);//masked_blit � una funzione di allegro che permette di renderizzare un'immagine, secondo me � l'unione fra getimage e putimage, 30 e 20 sono le dimensioni per l'immagine .bmp
}
//MUOVE L'ASTRONAVE
void Navicella::muove_astronave(){
	if(key[KEY_LEFT]&& x>=50){
		x -=5;
	}
	if(key[KEY_RIGHT] && x<=520){
		x +=5;
	}
}
//SPARO PER NAVICELLA/ALIENO
void Navicella::sparo_astronave(struct Spari spari[], BITMAP* sfondo){
		if(tipo==1){//Se � un alieno 
			crea_sparo(n_spari,max_spari,spari, x, y, velocita_spari);//Proiettile e sfondo sono i bmp
		}
	//If per gestire gli spari umani: per distinguere bene gli spari uno dall'altro ho bisogno di "rallentare" il processo di sparo utilizzando un tempo che si incrementa a ogni ciclo
	renderizza_sparo(n_spari,max_spari,spari,sfondo,proiettile,larghezza_proiettile,altezza_proiettile);//Per fortuna che ho capito le strutture :) 6 e 12=dimensioni immagine bmp dello sparo umano
	elimina_sparo(n_spari,max_spari,spari,larghezza,altezza);//spari � la struttura
}

void Navicella::renderizza_vite(BITMAP* sfondo){
	for(int i=0; i<vita; i++){
		masked_blit(navicella, sfondo,0,0,480+i*30,50,30,20);
	}
}

//GENERA GLI ALIENI
void crea_alieni(struct Navicella Alieno[]){
	int ind = -1;
	int tipo_alieno=0;//Indice per gli sprites degli alieni
	for(int i=0; i<5; i++){
		//Vedi bene coe sono disposti gli alieni in quello originale
		tipo_alieno++;
		if(tipo_alieno==4){tipo_alieno=1;}
		for(int j=0; j<11; j++){
			ind++;
			Alieno[ind].crea_astronave("./Immagini/Alieni.bmp", "./Immagini/Sparo_alieno.bmp", 6,12, 25, 20, 140+j*30, 130+i*24,8, tipo_alieno, 1, "./Audio/Sparo_alieno.wav", "./Audio/Esplosione_aliena.wav");//L'ultimo numero � il tipo
		}
	}
}
//RENDERIZZA GLI ALIENI CON I VARI STATI
void renderizza_alieni(struct Navicella Alieno[], BITMAP* sfondo, int stato_alieno){//Stato alieno serve per scegliere se l'alieno cambia "stato"
	int ind = -1;
	for(int i=0; i<5; i++){
		for(int j=0; j<11; j++){
			ind++;
			if(Alieno[ind].vita>0){
				Alieno[ind].renderizza_astronave(sfondo,stato_alieno,Alieno[ind].tipo-1);
			}
		}
	}
}
//QUANDO UNO SPARO IMPATTA QUALCOSA
bool elimina_sparo_collisione (struct Navicella& Nave, struct Navicella& Alieno, struct Spari proiettili[]){//Struct Navicella& Nave=chi spara, Struct Navicella& Alieno=chi riceve, Struct Spari proiettili=cosa spara
	if ( Nave.n_spari > 0 && Nave.n_spari < Nave.max_spari){
       for ( int cont = 1; cont <= Nave.n_spari; cont++){
          if(colpito(Alieno.x,Alieno.y, Alieno.larghezza_astronave, Alieno.altezza_astronave,proiettili[cont].x, proiettili[cont].y, Nave.larghezza_proiettile, Nave.altezza_proiettile) && Alieno.vita>0){
          	distruggi(proiettili,Nave.n_spari,cont);
          	Alieno.vita-=1;
          	return true;
		  }
       }
       return false;
	}
}

//PER ELIMINARE UNO COLPO QUANDO IMPATTA SULLE BARACCHE E DARLE DANNO
void elimina_sparo_baracca(struct Navicella &Nave, struct baracca pareti[], struct Spari proiettili[]){
	if ( Nave.n_spari > 0 && Nave.n_spari < Nave.max_spari){
       for ( int cont = 1; cont <= Nave.n_spari; cont++){
			for(int i=0; i<20; i++){//20 muri
				if(colpito(pareti[i].x, pareti[i].y, 20,16, proiettili[cont].x,proiettili[cont].y, Nave.larghezza_proiettile, Nave.altezza_proiettile)&&pareti[i].danno<3){
					distruggi(proiettili,Nave.n_spari,cont);
					pareti[i].danno++;
				}
			}
		}
	}
}


//ESPLOSIONE ALIENA
void esplosione_1(struct Navicella Alieno, BITMAP* sfondo){//ESPLOSIONE ALIENA
	play_sample(Alieno.esplosione,100,150,1000,0);
	BITMAP* temporaneo=create_bitmap(25,20);//Creo un bitmap grande com el'alieno
	clear_to_color(temporaneo,0x000000);//Lo coloro di nero
	blit(temporaneo,sfondo,0,0,Alieno.x,Alieno.y,25,20);//Rimpiazzo l'alieno con il temporaneo
	masked_blit(Alieno.esplosione_alieno, sfondo, 0,0, Alieno.x-10, Alieno.y, 41,34);//Visto che l'immagine dell'esplosione � un pelo pi� grande dell'alieno, devo allargarla
	
}
//ESPLOSIONE NAVICELLA
void esplosione_2(struct Navicella Nave, BITMAP* sfondo, BITMAP* immagine_sfondo){
	play_sample(Nave.esplosione,100,150,1000,0);
	BITMAP* temporaneo=create_bitmap(30,20);//Creo un bitmap grande com el'alieno
	clear_to_color(temporaneo,0x000000);//Lo coloro di ner
	for(int k=0;k<6; k++){
		for(int i=1; i<=2; i++){//Per controllare le immagini delle esplosioni della nave
			blit(temporaneo,sfondo,0,0,Nave.x,Nave.y,30,20);
			masked_blit(Nave.navicella, sfondo,i*30,0,Nave.x,Nave.y,30,20);//Nave.navicella=immagine bmp navicella, sfondo=bmp sfondo, i*30=movimento x di 30, 0=non muovo la y,Nave.x=x iniziale, Nave.y=y iniziale,30=x finale, 20=y finale
			renderizza_sfondo(immagine_sfondo,sfondo);
			blit(sfondo, screen, 0,0,0,0,larghezza,altezza);
			rest(50);
		}
	}
}

//CREA BARACCHE
void crea_scudo(struct baracca pareti[]){
	char posizione_pareti[3][22]={//Come per la versione non grafica
		"AEC   AEC   AEC   AEC",//Le lettere sono state messe in ordine in base alle skin dell'immagine .bmp
		"B D   B D   B D   B D",//Totale 20 muri (ovviamente non si contano gli spazi neh! Rincitrulllito di un Giuliano che sei)
	};
	int l=0;
	for(int i=0; i<21; i++){
		for(int j=0; j<2; j++){
			if(posizione_pareti[j][i] != ' '){
				pareti[l].x=90+i*20;//90=coordinata x iniziale della baracca,20=dimensione x immagine singola skin della baracca 
				pareti[l].y=450+j*15;//450=coordinata y iniziale della baracca,15=dimensione y immagine singola skin della baracca
				pareti[l].danno=0;//All'inizo nessun muro � danneggiato 
				if(posizione_pareti[j][i]=='A'){pareti[l].tipo=0;}//Tipo identificatore per il pezzo di bmp utilizzato per la superficie A della baracca
				if(posizione_pareti[j][i]=='B'){pareti[l].tipo=1;}//Tipo identificatore per il pezzo di bmp utilizzato per la superficie B della baracca
				if(posizione_pareti[j][i]=='C'){pareti[l].tipo=2;}//Tipo identificatore per il pezzo di bmp utilizzato per la superficie C della baracca
				if(posizione_pareti[j][i]=='D'){pareti[l].tipo=3;}//Tipo identificatore per il pezzo di bmp utilizzato per la superficie D della baracca
				if(posizione_pareti[j][i]=='E'){pareti[l].tipo=4;}//Tipo identificatore per il pezzo di bmp utilizzato per la superficie E della baracca
				l++;
			}
		}
	}
}

//RENDERIZZA LE BARACCHE
void renderizza_scudo(struct baracca renderizza_pareti[], BITMAP* immagine_parete, BITMAP* sfondo){
	for(int i=0; i<20; i++){
		if(renderizza_pareti[i].danno!=3){//Quando non � distrutta
			masked_blit(immagine_parete, sfondo, renderizza_pareti[i].danno*20, renderizza_pareti[i].tipo*16, renderizza_pareti[i].x, renderizza_pareti[i].y, 20,16);//20=larghezza di una skin del muro, 16=altezza di una skin del muro
		}
	}
}

//CREA I COLPI ALIENI
void crea_acido_alieno(struct Navicella Alieno[], int &n){
	if(Alieno[n].n_spari==0){//Se non ha ancora sparato
		n=rand()%55;
		while(Alieno[n].vita==0){//Se muoiono, non sparano pi�
			n=rand()%55;
		}
				
	}

}

//CREA GLI SPARI UMANI
void crea_sparo_umano(struct Navicella Nave,struct Spari spari[]){
	if(key[KEY_SPACE] && Nave.gestione_tempo(20)){
	   crea_sparo(Nave.n_spari,Nave.max_spari, spari, Nave.x, Nave.y,Nave.velocita_spari);
	}
}

//DEFINISCE I LIMITI DELLA MAPPA PER I MOVIMENTI ALIENI
bool limite_mappa(struct Navicella Alieno[], int &direzione){
	for(int i=0; i<55; i++){
		if((Alieno[i].x>520 || Alieno[i].x<50) && Alieno[i].vita){//Ci sono due parentesi (ci sono impazzito) perch� quando rimaneva un solo nemico, non toccava mai l'estremo della mappa, teneva salvata anche la posizione degli altri alieni, quindi mettendo le parentesi impongo che prima quelle condizioni vengano verificate
			direzione=-1*direzione;//Faccio diventare la direzione negativa
			return true;
		}
	}
	return false;
}

//MUOVE GLI ALIENI
void muovi_alieni(struct Navicella Alieno[], int&stato_alieno, int&direzione){
	for(int i=0; i<55; i++){Alieno[i].x+=direzione;}
	if(stato_alieno++== 1){stato_alieno=0;}
	if(limite_mappa(Alieno,direzione)){
		for(int j=0; j<55; j++){
			Alieno[j].y +=10;
		}
	}
}

//SE GLI ALIENI ARRIVANO IN FONDO
bool alieni_infondo(struct Navicella Alieno[]){
	for(int i=0; i<55; i++){
		if(Alieno[i].y>=460){
			return true;
		}
	}
	return false;
}
int main(){
	srand(time(NULL));
	
    inizio_allegro(larghezza,altezza); //funzione in inizio.h
	inizio_audio(70,70);  //funzione in inizio.h 70=volume file midi/mp3 70=volume file wav
	install_mouse();//Altra funzionde di allegro per controllare il mouse
	
	//IMMAGINI
    BITMAP *sfondo = create_bitmap(larghezza, altezza);
    BITMAP *sfondo_menu=create_bitmap(larghezza,altezza);
	BITMAP *menu_vero=load_bitmap("./Immagini/menu_gioco.bmp",NULL);
	BITMAP *menu_gioca=load_bitmap("./Immagini/menu_gioco_GIOCA.bmp", NULL);
	BITMAP *menu_opzioni=load_bitmap("./Immagini/menu_gioco_OPZIONI.bmp", NULL);
	BITMAP *menu_esci=load_bitmap("./Immagini/menu_gioco_ESCI.bmp", NULL);
	BITMAP *opzioni_terrestre=load_bitmap("./Immagini/opzioni_terrestre.bmp",NULL);
	BITMAP *opzioni_terrestre_seleziona=load_bitmap("./Immagini/opzioni_terrestre_seleziona.bmp",NULL);
	BITMAP *opzioni_terrestre_modalita=load_bitmap("./immagini/opzioni_terrestre_modalita.bmp", NULL);
	BITMAP *opzioni_cosmonauta=load_bitmap("./Immagini/opzioni_cosmonauta.bmp",NULL);
	BITMAP *opzioni_cosmonauta_seleziona=load_bitmap("./Immagini/opzioni_cosmonauta_seleziona.bmp",NULL);
	BITMAP *opzioni_cosmonauta_modalita=load_bitmap("./immagini/opzioni_cosmonauta_modalita.bmp", NULL);
	BITMAP *cursore=load_bitmap("./Immagini/cursore.bmp",NULL);
    BITMAP *immagine_menu=load_bitmap("./Immagini/si_menu.bmp",NULL);
    BITMAP *immagine_sfondo=load_bitmap("./Immagini/sfondo.bmp",NULL);
    BITMAP *immagine_pareti=load_bitmap("./Immagini/Baracca.bmp",NULL);
    BITMAP *vittoria=load_bitmap("./Immagini/VITTORIA.bmp",NULL);
    BITMAP *sconfitta=load_bitmap("./Immagini/SCONFITTA.bmp", NULL);
	SAMPLE *sottofondo=load_wav("./Audio/SpaceInvaders.wav");
	SAMPLE *musica_menu=load_wav("./Audio/Menu.wav");
	SAMPLE *fine_vittoria=load_wav("./Audio/Vittoria.wav");
	SAMPLE *fine_sconfitta=load_wav("./Audio/Lose.wav");
    //Assegno a Nave le stesse propriet� di navicella
    Navicella Nave;
    Nave.crea_astronave("./Immagini/Navicella.bmp", "./Immagini/Sparo_umano.bmp", 6,12,30,20,larghezza/2,altezza-70, -12, 0, 3, "./Audio/Sparo_umano.wav", "./Audio/Esplosione.wav");
	Navicella Alieno[60];
	crea_alieni(Alieno);
	Spari spari[Nave.max_spari];//Struttura di spari.h Utilizzo max_spari dalla struttura della navicella
	Spari acido_alieno[Alieno[0].max_spari];
	
	baracca renderizza_pareti[30];
	crea_scudo(renderizza_pareti);
	
	int durata_musica=0;
	int durata_musica_menu=0;
	bool suona=true;
	bool suona_menu=true;
	play_sample(musica_menu,100,150,1000,0);
	bool scendi_menu=false;
	bool seleziona=false;//Per selezionare le opzioni nelle opzioni
	bool cambia_modalita=false;//Per cambiare modalit�nelle opzioni
	int difficolta=0;
	int n;
	int stato_alieno;
	int direzione;
	int velocita_alieni;
	int alieni;
	while(scendi_menu==false){
		seleziona=false;
		cambia_modalita=true;
		//SE PREMI GIOCA
		if(mouse_x > 229 && mouse_x<373 && mouse_y<308 && mouse_y>269){//Molto simile a Graphics
			blit(menu_gioca,sfondo_menu,0,0,0,0,larghezza,altezza);
			if(mouse_b &1){//mouse_b & 1 = click sinistro, mouse_b & 2 = click destro
				if(difficolta==0){
					n=rand()%55;//Genero un numero casuale per scegliere l'alieno che spara
					stato_alieno=0;//Stato bitmap alieno
					direzione=-5;//Direzione della massa di alieni
					velocita_alieni=10 ;//Pi� � bassa, pi� sono veloci
					alieni=55;
					Nave.max_spari=2;
					//tempo_alieno_1=300;
				}
				if(difficolta==1){
					n=rand()%55;//Genero un numero casuale per scegliere l'alieno che spara
					stato_alieno=0;//Stato bitmap alieno
					direzione=-8;//Direzione della massa di alieni
					velocita_alieni=8;//Pi� � bassa, pi� sono veloci
					alieni=55;
					Nave.vita=2;
					Nave.max_spari=2;
					//tempo_alieno_1=500;
				}
				clear_to_color(sfondo_menu,0x000000);
				blit(sfondo_menu,screen, 0,0,0,0,larghezza,altezza);
				crea_sfondo(immagine_menu);
				while(!key[KEY_ESC] && Nave.vita>0 && alieni>0){
					if(alieni_infondo(Alieno)){
						Nave.vita=0;
					}
					stop_sample(musica_menu);
					//Con Allegro=2300
					//Senza Allegro=1390
					if(durata_musica==1390){suona=true; durata_musica=0;}//Handmade music loop
					if(suona==true){
						play_sample(sottofondo,100,150,1000,0);
						suona=false;
					}
					clear_to_color(sfondo,0x000000);
					renderizza_scudo(renderizza_pareti,immagine_pareti,sfondo);	
					if(Alieno[0].gestione_tempo(velocita_alieni)){
						muovi_alieni(Alieno,stato_alieno,direzione);
					}
					if(Alieno[1].gestione_tempo(500)){
						if(velocita_alieni>=2){
							velocita_alieni-=1;
							if(direzione<0){direzione+=-1;}
							else direzione +=1;
						}
					}
					Nave.renderizza_astronave(sfondo,0,0);
					Nave.muove_astronave(); 
					//crea_sparo_umano(Nave,spari);
					if(key[KEY_SPACE] && Nave.gestione_tempo(10)){
						if(crea_sparo(Nave.n_spari,Nave.max_spari, spari, Nave.x, Nave.y,Nave.velocita_spari)){
							play_sample(Nave.sparo,100,150,1000,0);//100=volume, 150=effetto, 1000=frequenza, 0 � combinato con la frequenza 
						}	
					}
					Nave.sparo_astronave(spari,sfondo);
					
					for(int i=0; i<55; i++){
						if(elimina_sparo_collisione(Nave,Alieno[i], spari)){//E' booleana
							esplosione_1(Alieno[i],sfondo);
							alieni--;
						}
					}
					elimina_sparo_baracca(Nave,renderizza_pareti,spari);
					renderizza_alieni(Alieno, sfondo,stato_alieno);
					crea_acido_alieno(Alieno,n);
					Alieno[n].sparo_astronave(acido_alieno,sfondo);//n=numero casuale
					if(elimina_sparo_collisione(Alieno[n], Nave, acido_alieno)){
						esplosione_2(Nave,sfondo,immagine_sfondo);
					}
					elimina_sparo_baracca(Alieno[n],renderizza_pareti,acido_alieno);
					renderizza_sfondo(immagine_sfondo, sfondo);//Disegna losfondo
					Nave.renderizza_vite(sfondo);
					blit(sfondo,screen, 0,0,0,0,larghezza, altezza);//Copia un rettangolo da sfondo a screen (che allegro riconosce come finestra aperta)
					rest(20);//Simile allo sleep, � sempre in millisecondi
					durata_musica++;
				}
				scendi_menu=true;
			}
		}
		//SE PREMI OPZIONI
		else if (mouse_x>212 && mouse_x<398 && mouse_y>334 && mouse_y<372){
			blit(menu_opzioni,sfondo_menu,0,0,0,0,larghezza,altezza);
			if(mouse_b &1){//mouse_b & 1 = click sinistro, mouse_b & 2 = click sinistro
				while (cambia_modalita==true){
					cambia_modalita=false;
					clear_to_color(sfondo_menu,0x000000);
					blit(sfondo_menu,screen, 0,0,0,0,larghezza,altezza);
					blit(opzioni_terrestre,sfondo_menu,0,0,0,0,larghezza,altezza);
					while(seleziona==false && cambia_modalita==false){
						if(mouse_x>505 && mouse_x<535 && mouse_y>220 && mouse_y<260){
							blit(opzioni_terrestre_modalita,sfondo_menu,0,0,0,0,larghezza,altezza);
							if(mouse_b &1){//Se clicchi la frecccia da TERRESTRE
								clear_to_color(sfondo_menu,0x000000);
								blit(sfondo_menu,screen, 0,0,0,0,larghezza,altezza);
								blit(opzioni_cosmonauta,sfondo_menu,0,0,0,0,larghezza,altezza);
								while(seleziona==false && cambia_modalita==false){
									if(mouse_x>29 && mouse_x<59 && mouse_y>220 && mouse_y<260){
										blit(opzioni_cosmonauta_modalita,sfondo_menu,0,0,0,0,larghezza,altezza);
										if(mouse_b &1){//Se clicchi la freccia da COSMONAUTA
											cambia_modalita=true;
										}
										
									}
									else if(mouse_x>40 && mouse_x<210 && mouse_y>448 && mouse_y<474){
										blit(opzioni_cosmonauta_seleziona,sfondo_menu,0,0,0,0,larghezza,altezza);
										if(mouse_b &1){//Se clicchi seleziona da COSMONAUTA
											seleziona=true;
											scendi_menu=false;
											difficolta=1;
										}
									}
									else blit(opzioni_cosmonauta,sfondo_menu,0,0,0,0,larghezza,altezza);
									masked_blit(cursore,sfondo_menu,0,0,mouse_x,mouse_y,16,24);
									blit(sfondo_menu,screen, 0,0,0,0,larghezza,altezza);	
								}
							}
						}
						else if(mouse_x>40 && mouse_x<210 && mouse_y>448 && mouse_y<474){
							blit(opzioni_terrestre_seleziona,sfondo_menu,0,0,0,0,larghezza,altezza);
							if(mouse_b &1){//Se clicchi seleziona da TERRESTRE
								seleziona=true;
								scendi_menu=false;
								difficolta=0;
							}
						}
						else blit(opzioni_terrestre,sfondo_menu,0,0,0,0,larghezza,altezza);
						masked_blit(cursore,sfondo_menu,0,0,mouse_x,mouse_y,16,24);
						blit(sfondo_menu,screen, 0,0,0,0,larghezza,altezza);
					}	
				}
			
			}
		}
		//SE PREMI ESCI
		else if (mouse_x>245 && mouse_x<352 && mouse_y>397 && mouse_y<441){
			blit(menu_esci,sfondo_menu,0,0,0,0,larghezza,altezza);
			if(mouse_b &1){//mouse_b & 1 = click sinistro, mouse_b & 2 = click sinistro
			  scendi_menu=true;		
			}
		} else blit(menu_vero,sfondo_menu,0,0,0,0,larghezza,altezza);
		masked_blit(cursore,sfondo_menu,0,0,mouse_x,mouse_y,16,24);
		blit(sfondo_menu,screen, 0,0,0,0,larghezza,altezza);	
	}
	if(Nave.vita==0){
		stop_sample(sottofondo);
		play_sample(fine_sconfitta,100,150,1000,0);
		while(!key[KEY_ESC]){
			blit(sconfitta,sfondo_menu,0,0,0,0,larghezza,altezza);
			masked_blit(cursore,sfondo_menu,0,0,mouse_x,mouse_y,16,24);
			blit(sfondo_menu,screen, 0,0,0,0,larghezza,altezza);
		}
	}
	if (alieni==0){
		stop_sample(sottofondo);
		play_sample(fine_vittoria,100,150,1000,0);
		while(!key[KEY_ESC]){
			blit(vittoria,sfondo_menu,0,0,0,0,larghezza,altezza);
			masked_blit(cursore,sfondo_menu,0,0,mouse_x,mouse_y,16,24);
			blit(sfondo_menu,screen, 0,0,0,0,larghezza,altezza);
		}
	}
	return 0;
}
END_OF_MAIN();

