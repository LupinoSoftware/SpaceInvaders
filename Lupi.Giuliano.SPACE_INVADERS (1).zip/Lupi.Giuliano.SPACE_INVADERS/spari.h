#include <allegro.h>
#ifndef SPARI_H//per controllare se � incluso
#define SPARI_H

//SPARI_H
struct Spari{
    int x , y;
    int dx , dy;//direzione x, direzione y

};

bool colpito(int x1, int y1, int larghezza_1, int altezza_1, int x2, int y2, int larghezza_2, int altezza_2);

bool crea_sparo(int& n_spari, const int max_spari,struct Spari pari[], const int X, const int Y ,const int dy);

void renderizza_sparo(int& n_spari, const int max_spari,struct Spari spari[], BITMAP* buffer, BITMAP* sparo, int larghezza, int altezza);

void distruggi (struct Spari spari[], int& n_spari, int cont);

void elimina_sparo(int& n_spari, const int max_spari,struct Spari spari[], const int larghezza, const int altezza);

bool elimina_sparo_collisione (struct Navicella& Nave, struct Navicella& Alieno, struct Spari proiettili[]);//Navicella& Nave: creo una struttura con gli stessi dati di Navicella, ma che posso modificare

void elimina_sparo_baracca(struct Navicella &Nave, struct baracca pareti[], struct Spari proiettili[]);
#endif // per 
