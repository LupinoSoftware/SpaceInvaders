#include "menu.h"
#include <allegro.h>

void crea_sfondo(BITMAP* sfondo){
	int refresh=0;
	int y=0;
	int cont=0;
	bool scendi=false;
	bool cambio=false;
	while(scendi==false){
		if(refresh<25){
			blit(sfondo,screen, 0,y,0,100, 600,400);
		}
		else{
			blit(sfondo,screen,603,y,0,100,600,400);
		}
		if(key[KEY_ENTER]){
			y=400;//Cambiando la y, l'immagine da prendere ha cordinate +400
			cambio=true;
		}
		if(cambio){
			cont++;
			if(cont>400){//cont � perforza >400
				scendi=true;
			}
		}
		rest(5);
		if(refresh++ == 100){refresh=0;}	
	}
	
	clear_to_color(screen,0x000000);
}

void renderizza_sfondo(BITMAP* immagine, BITMAP* sfondo){
	masked_blit(immagine,sfondo,0,0,0,0,600,600);
}
