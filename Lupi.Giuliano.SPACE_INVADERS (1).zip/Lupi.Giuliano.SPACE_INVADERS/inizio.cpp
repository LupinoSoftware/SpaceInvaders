#include "inizio.h"
#include <allegro.h>

void inizio_allegro(int LARGHEZZA_ , int ALTEZZA_){
   allegro_init();
   install_keyboard();//Utilizzando allegro, per gli input da tastiera posso fare cos�
   set_color_depth(32);//Per la risoluzion 
   set_gfx_mode(GFX_AUTODETECT_WINDOWED, LARGHEZZA_, ALTEZZA_, 0, 0);//Per settare la modalit� grafica, grazie a StachOverflow sono riuscito a capire come funziona :)
}

//Provo a fare la musica grazie ad Allegro
int inizio_audio(int sinistra, int destra){
    if (install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL) != 0) {
       allegro_message("Errore: problema nel far  partire l'audio\n\n", allegro_error);//Emette un messaggio di errore, � molto simile a Javascript
       return 1;
    }

	set_volume(sinistra, destra);
}


