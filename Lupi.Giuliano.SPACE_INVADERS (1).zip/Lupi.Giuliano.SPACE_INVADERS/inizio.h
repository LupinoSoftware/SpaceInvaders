#ifndef INIZIO_H_INCLUDED
#define INIZIO_H_INCLUDED

void inizio_allegro(int LARGHEZZA_ , int ALTEZZA_);
int inizio_audio(int sinistra, int destra);

#endif // INICIA_H_INCLUDED

