#include "spari.h"
#include <allegro.h>

bool colpito(int x1, int y1, int larghezza_1, int altezza_1, int x2, int y2, int larghezza_2, int altezza_2){
	if(x1<x2+larghezza_2 && x2<x1+larghezza_1 && y1<y2+altezza_2 && y2<y1+altezza_1){
		return true;
	}
	else{return false;}
}

bool crea_sparo(int& n_spari, const int max_spari ,struct Spari spari[] ,const int X, const int Y , const int dy)
{
              if( n_spari < max_spari-1){ // Permetto solo di sparare n-1 spari
                   n_spari++;
	
					//Gestisco le coordinate e direzioni utilizziando le variabili della struttura spari
                   spari[n_spari].x  = X+11;
                   spari[n_spari].y  = Y;
                   spari[n_spari].dx = 0;
                   spari[n_spari].dy = dy;
                   return true;
               }
               return false;

}

void renderizza_sparo(int& n_spari, const int max_spari,struct Spari spari[],BITMAP* buffer, BITMAP* proiettile, int larghezza, int altezza)
{
//Funzione che permette di spostare lo sparo utilizzando i parametri della struttura spari andando a modificare coordinate e direzioni	
     if ( n_spari > 0 && n_spari < max_spari){
            for ( int cont = 1; cont <= n_spari; cont++){
                       spari[cont].x += spari[cont].dx;
                       spari[cont].y += spari[cont].dy;
                       masked_blit( proiettile, buffer, 0, 0, spari[cont].x, spari[cont].y, larghezza, altezza);//Per dare la trasparenza se avessi usato un colore diverso dal nero come sfondo dei bitmap
            }
     }

}

void distruggi (struct Spari spari[], int& n_spari, int cont){
	  Spari Ptemp;
	  Ptemp = spari[cont];
      spari[cont] = spari[n_spari];
      spari[n_spari] = Ptemp;
      n_spari--;
      if ( n_spari < 0 ) n_spari=0;
}

void elimina_sparo(int& n_spari, const int max_spari,struct Spari spari[],const int larghezza, const int altezza)
{
      //Spari Ptemp;//Ptemp � una variabile temporanea che utilizzo per cancellare il proiettile grazie alla struttura spari
      if ( n_spari > 0 && n_spari < max_spari){
            for ( int cont = 1; cont <= n_spari; cont++){
                      if ( spari[cont].y > altezza || spari[cont].y < 0 ||
                           spari[cont].x > larghezza || spari[cont].x < 0  )
                       {
                                /*Ptemp = spari[cont];
                                spari[cont] = spari[n_spari];
                                spari[n_spari] = Ptemp;
                                n_spari--;
                                if ( n_spari < 0 ) n_spari=0;*/
                                distruggi(spari,n_spari,cont);
                       }
            }
      }
}

