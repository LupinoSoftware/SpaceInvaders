#include <allegro.h>
#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

void crea_sfondo(BITMAP* sfondo);
void renderizza_sfondo(BITMAP* immagine, BITMAP* sfondo);

#endif
